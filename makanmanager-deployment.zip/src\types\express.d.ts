declare module 'express' {
  export function Router(): any;
  const anyExport: any;
  export default anyExport;
}
